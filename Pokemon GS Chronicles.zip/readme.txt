========================
Pok�mon GS Chronicles
========================

Status: Beta
Version: 2.0
Build: 1611192_0
Date: November 17, 2018

========================
What's New
========================

This file is an .ups patch, and cannot be installed
using lunar IPS; you must need NUPS patcher to
aplly this patch into a clean 1636 - Pokemon Fire Red (U)(Squirrels)
or you can just activate the function of autopatch
from Visualboy or Myboy (Or GBA4IOS maybe?)

=====================
What Can I Do?
====================

In this beta you can earn 6 badges. Beta will end
rifg after you defeat Jasmine's gym.


=====================
Bugs and oddities
=====================

- After you run out of Pok�mon and the last visited place
was your mom's house, the respawn coordinates will be wrong.
- Rival frames when you name him are broken.
- ON ROUTES 29 AND 30 THE MAY BE RANDOM SOFTLOCKS WHILE WALKING
OR JUST BY STANDING IDLE. I RECOMMEND YOU TO SAVE CONSTANTLY ON
THESE ROUTES (I TRIED SEVERAL TIMES TO FIND THE BUG)
- Some battle texts, like leftover message or damage reduction berries,
are shown blank, but they work fine.
- In Cherrygrove's PC some npc's randomly disappear with no reason.
- DO NOT TRY TO USE LINK FUNCIONS FROM PC's. IT MAY DESTROY
YOUR SAVE FILE.
- The vs bars are affected by DNS (It's not a bug at all)
- Some doors are not yet animated (It's not a bug at all)

If you find a bug, please report it to me.

You can find the full list of credits here:
https://whackahack.com/foro/t-34858/pokemon-gs-chronicles

My Discord: Anon_User#0528
Discord server: https://discord.gg/nZbAb32
twitter: @Rukirh
Youtube: Youtube.com/c/Rukistudios

� 2010-2018 Ruki Studios. This project is a fanmade and
is not intended for sale. The Pok�mpon Franchise is
property of The Pok�mon Company International and
Nintendo.