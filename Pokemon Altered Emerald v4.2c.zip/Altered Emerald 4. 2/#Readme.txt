Welcome to Altered Emerald! Hope you enjoy! There's a lot of documentation - you don't need to read it to have a good time.

If you downloaded this somewhere other than Pokecommunity, I recommend making an account there. It's a good, convenient forum, and it doesn't run scam ads.

To patch your unedited Pokemon Emerald rom, I recommend LunarIPS: http://fusoya.eludevisibility.org/lips/ The game is best experienced on VBA-M, but should work on most emulators. I know that My Boy! also works, as does the mobile version of VBA. No$gba works fine but causes an incredibly annoying visual glitch with fog.

Beware of Innards Out Poliwrath during Nuzlockes.

Thanks for playing!



Special Thanks:
All of Pokecommunity. Dizzy Egg, Lunos, Chacha Dinosaur, HackMew, Lu-Ho, Gamer2020, Scizz, Silver314, MastermindX, link12552, and all the contributors to romhacking tools, romhacking, and the stunning pokeemerald disassembly. And FuSoYa (for LIPS) and the wider romhacking community at large!

There is a file in this folder called "roms". This lets you use Gamer2020's Pokemon Game Editor (PGE) to make any changes to Altered Emerald you like.

===

Important bugs
- Use regular save states: the game has been reported to cause bad EGGs very rarely. The in-game "save" function is not as trustworthy as savestates. The battle frontier corrupts savestates.
- If a Ditto with Imposter transforms into a Pokemon with Gravitate, the game freezes. This does not corrupt save states (so you should be able to reload from an earlier point in the rom), but it may corrupt the game's save file (so if you use the game's internal save function, rather than an emulator save state, the save could be corrupted)
- Selfdestruct has been reported causing the game to crash under conditions I've not managed to replicate.
- If you find an enemy trainer's Pokémon using sketch, Impostor, or Transform, please report it on the discord, that has caused problems in the past.



