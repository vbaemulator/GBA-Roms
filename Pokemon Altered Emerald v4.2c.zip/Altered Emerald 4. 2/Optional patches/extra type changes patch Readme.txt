The type change patch is only recommended if you've played the base game a bit and want to switch things up.

Type changes are a very quick and easy way to change the whole game a bit. In much the same way that spit is a very quick and easy way to change a drawing.

These are changes that I've experimented with and cut. I think they're all alright, but they are not communicated to the player well. Unless you remember each one individually, they will often make enemy trainers irritating to fight. I'm no longer balancing the game around these changes - i.e the patch makes ledian, volbeat, stantler and nidoran quite strong.


Charizard to fire/dragon
Butterfree to bug/psy
Nidoran/ina/ino to poison/normal
Hypno to Psy/Fight
Ninetales to fire/psy
Golduck to Water/ghost
Muk to Poison/dark
Kingler to Water/Steel
Kangaskhan to Normal/fight
Gyarados to Water/Dragon
Rapidash to Fire/Fairy, and learning Play Rough
Venonat/moth to Bug/Dragon
Pinsir to Bug/Dark (note 
Mewtwo to Psychic/Dark

Meganium to grass/fairy
feraligatr to water/dark
Ledian to Bug/Electric 
Flaafy/ampharos to Elec/Fairy -
Sunflora to Grass/Fire
Dunsparce to Normal/Grnd
Stantler to Normal/Psychic

Sceptile to Grass/Fight
Shedinja to Bug/Dark 
Volbeat to bug/elec 
Illumise to bug/fairy 
Swellow to Fly/Fight 
Nosepass to Rock/Elec
Torkoal to Fire/Steel
Altaria to Dragon/Fairy
Cacturne to Grass/Ghost
Absol to dark/Normal
Chimecho to psy/ghost
Jirachi to psy/fairy

Electivire to Elec/Fighting
Magmortar to Fire/Fighting
