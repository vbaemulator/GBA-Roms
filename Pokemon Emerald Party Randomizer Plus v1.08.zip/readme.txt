=====================================================================
=============== Pokemon Emerald Party Randomizer Plus ===============
===============                (PEPR+)                ===============
=====================================================================

----Features----

This is a romhack for Pokemon Emerald that randomizes all of the Pokemon of your party at the beginning of every battles. Every Pokemon changes specie and gets a new moveset, while preserving EV points, IV points, contest conditions, current HP percentage, XP percentage, shiny, pokerus and nickname across randomizations.

The following features were added on top of Googleben's Party Randomizer:

- Pokemon evolve within specific level ranges, at random. A level 5 Pokemon will always be in its first stage evolution, while a level 60 Pokemon will always be fully evolved.
- Legendary Pokemons are rarer to get when low level. They gain the same chances to appear as any Pokemon family after level 40.
- Every Pokemon has a chance to obtain an Egg move. The higher level you are, the higher the chances, capping at level 20.
- Pokemon choose from a slightly wider level-up movepool and choose from the previous evolution in case of a Stone evolution Pokemon.
- Every Pokemon can learn moves from the TM/HM you currently have in your bag. Each TM/HM you have increases the chances for each Pokemon to learn a TM/HM move by 10%, making it 100% certain to learn something if you have at least 10 TM/HM. If the Pokemon learns a TM/HM, it will choose one of the compatible moves from what you have. Managing the TMs you carry around may thus allow you to control to some degree what your Pokemon can learn, but you can't just leave one TM so that all your Pokemon learns it all the time!
- HMs can be deposited into the PC. As such, you don't need to avoid getting the weaker HMs to remove them from the possible TM pool.
- For both Egg moves and TM/HM moves, if the Pokemon already has a full moveset, it will give a score to each move according to how essential it is offensively, and replace only moves that are given the lower score, or a move of the same typing if considered better. This means that duplicate typing moves and status moves are prioritized.
- Smeargle gets an entirely randomized moveset, according to the amount of times it should have learned Sketch by its level.
- Booting up an HM randomizes the Team again, so that you don't end up stuck on islands with no Pokemon able to Surf.
- Ability is randomized.


----Versions----

v.1.08
- Pokemon now attempt to relearn the 5th latest level-up move, fixing a few movesets like Oddish with Sweet Scent + all 3 Powder moves.
- Pokemon that evolve by stone now also attempt relearning the last 4 level-up moves from the previous evolution.
- Fixed no-miss offensive moves being evaluated as low power
- Small tweak to the replacement algorithm for support moves.

v.1.07
- Reversed priority for duplicate typing moves and status moves. Duplicate moves are now always prioritized.
- Changed the algorithm for selecting moves to replace so it always chooses the moves considered the most useless.

v.1.06
- Randomized abilities, fixing at the same time Slot 2 Ability Pokemon getting no Ability on species with only one ability.

v.1.05
- Made the party randomize again when booting up an HM, fixing the issues of getting stuck without a Pokemon able to use Surf.

v.1.04
- Fixed a possible infinite black screen when starting a battle.

v.1.03
- Added score system to moves, for better evaluation of which moves should be overriden.

v.1.02
- Lowered the Evolution level ranges, making Pokemon evolve earlier.
- Fixed Weedle so it evolves at the same range as Caterpie and Wurmple
- Allowed the depositing of HM.

v.1.01
- Added a rule that prevents a Pokemon from overwriting an offensive move with a support move.
- Made Smeargle's moveset entirely random, to avoid it being 100% useless knowing only Sketch.

v.1.00
- Finished the first version of the ROM hack.


----How to Patch----

Before starting, you will need the following:
- A copy of the ROM Pokemon Emerald (U). As sharing the ROM is illegal, you will need to obtain it by your own means. If patching fails, make sure that the SHA1 checksum of the base ROM is "f3ae088181bf583e55daf962a92bb46f4f1d07b7".
- Delta Patcher. Version 2.0.1 was the one used for the creation of the patch, but other versions may work too for patching. You can download it here: https://www.romhacking.net/utilities/704/
- The xdelta patch. If you have this readme, you surely have the patch already.


To patch, simply open Delta Patcher, select your Pokemon Emerald ROM as the Original file, select PEPRPlus.xdelta as the XDelta patch, and click Apply Patch.

If you wish to apply this romhack alongside other modifications such as randomizing the game with Universal Pokemon Randomizer, you must apply the other modifications first. When you apply the xdelta patch, click the gear button next to the "Apply patch" button, and make sure that "Checksum validation" is unchecked. The patch was confirmed to be compatible with Universal Pokemon Randomizer, but do note that it won't be compatible with most ROM hacks 


----Credits----
Pokemon Emerald Party Randomizer Plus was created by Souma. It has been created by building upon Googleben's Pokemon Emerald Party Randomizer. This was made possible by using the Disassembly project of Pokemon Emerald, by Pret.

Googleben's Pokemon Emerald Party Randomizer: 
https://github.com/googleben/EmeraldPartyRandomizer

Pret's Pokemon Emerald Disassembly Project: 
https://github.com/pret/pokeemerald